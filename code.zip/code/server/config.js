const Locate_Status = {
    NEW:"new",
    START:"start",
    FINISH:"finish"
}
const Driver_Status={
    FREE:"driver_free",
    START:"driver_start",
    FINISH:"driver_finish",
}
module.exports={
    JWT_SERCRET:"123567igfaskdngao822!@31",
    Locate_Status
}