
const Model = {
    Locate:require('./locate'),
    Driver:require('./driver'),
    Phone:require('./phone'),
    Point:require('./point'),
    User:require('./user')
}
module.exports = Model